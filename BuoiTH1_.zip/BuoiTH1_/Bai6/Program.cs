﻿using System.Text;

namespace Bai6
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.Write("Nhập lương cơ bản: ");
            double bs = double.Parse(Console.ReadLine());
            NhanVien.SetBasicSalary(bs);

            NhanVien emp = new NhanVien();
            emp.Input();

            Console.WriteLine("\n--- Thông tin nhân viên ---");
            emp.Display();

            Console.ReadLine();
        }
    }
}
